package com.example.practic_178;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practic178ApplicationTests {

	@Test
	void contextLoads() {
	}

}
