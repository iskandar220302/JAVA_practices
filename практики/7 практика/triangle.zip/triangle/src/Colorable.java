public interface Colorable {
    void howToColor();
}
