// Уровни сообщений
enum Level {
    INFO, WARNING, ERROR, CRITICAL, DEBUG
}
